from flask import Flask, render_template, request, redirect, url_for
import time
import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from sklearn.neighbors import NearestNeighbors

app = Flask(__name__)

testaidata = pd.read_csv("../cleaned_combined_data.csv")

# Define columns used for clustering, all containing numerical values to not clash with string values
numerical_columns = ['valence', 'year', 'acousticness', 'danceability', 'duration_ms', 
                     'energy', 'explicit', 'instrumentalness', 'key', 'liveness', 
                     'loudness', 'mode', 'popularity', 'speechiness', 'tempo', 'time_signature']


scaler = MinMaxScaler()
testaidata[numerical_columns] = scaler.fit_transform(testaidata[numerical_columns]) # Applies scale to the values above to fit them between 0-1 to make them easier to compare

# Extract normalised data from the frame and sets them in x for KNN
X = testaidata[numerical_columns]
knn = NearestNeighbors(n_neighbors=10, algorithm='auto') # Currently set up for 10 neighbours, can increase/decrease as needed
knn.fit(X)

@app.route('/', methods=['GET', 'POST'])
def input_songs():
    if request.method == 'POST':
        songs = [
            {'name': request.form['song1_name'], 'artist': request.form['song1_artist'], 'year': int(request.form['song1_year'])},
            {'name': request.form['song2_name'], 'artist': request.form['song2_artist'], 'year': int(request.form['song2_year'])},
            {'name': request.form['song3_name'], 'artist': request.form['song3_artist'], 'year': int(request.form['song3_year'])},
            {'name': request.form['song4_name'], 'artist': request.form['song4_artist'], 'year': int(request.form['song4_year'])},
            {'name': request.form['song5_name'], 'artist': request.form['song5_artist'], 'year': int(request.form['song5_year'])},
        ]
        return redirect(url_for('recommendations', songs=songs))
    return render_template('input_songs.html')

@app.route('/recommendations', methods=['GET'])
def recommendations():
    # Retrieve songs passed from the form
    songs = request.args.getlist('songs')
    
    recommendations = recommend_songs(songs)

    return render_template('recommendations.html', recommendations=recommendations)
def recommend_songs(songs):
    # Convert the input songs to a DataFrame, extracting the numerical features from Spotify (using a mockup for now since spotify API acting up)
    input_features = []
    for song in songs:
        mock_features = {
            'valence': 0.5,
            'year': 0.7,
            'acousticness': 0.4,
            'danceability': 0.6,
            'duration_ms': 0.8,
            'energy': 0.3,
            'explicit': 0.1,
            'instrumentalness': 0.5,
            'key': 0.6,
            'liveness': 0.3,
            'loudness': 0.7,
            'mode': 0.5,
            'popularity': 0.8,
            'speechiness': 0.4,
            'tempo': 0.6,
            'time_signature': 0.5
        }
        
        # Append the feature vector for this song
        input_features.append(list(mock_features.values()))
        
    # Normalize the input features the same way as the dataset
    input_features = np.array(input_features)
    input_features = scaler.transform(input_features)
    distances, indices = knn.kneighbors(input_features)
    recommended_songs = []
    for index_list in indices:
        for idx in index_list:
            recommended_songs.append({
                'name': testaidata.iloc[idx]['name'],
                'artist': testaidata.iloc[idx]['artists'],
                'year': testaidata.iloc[idx]['year']
            })
    return recommended_songs[:10]
if __name__ == '__main__':
    app.run(debug=True)