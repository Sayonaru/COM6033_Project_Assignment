from flask import Flask, render_template, request
import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from scipy.spatial.distance import cdist
from collections import defaultdict
import spotipy
from spotipy.oauth2 import SpotifyClientCredentials
import time

app = Flask(__name__)

data = pd.read_csv("../cleaned_combined_data.csv")

# Define columns used for clustering, all containing numerical values to not clash with string values
number_cols = ['valence', 'year', 'acousticness', 'danceability', 'duration_ms', 
               'energy', 'explicit', 'instrumentalness', 'key', 'liveness', 
               'loudness', 'mode', 'popularity', 'speechiness', 'tempo']

# Set up clustering pipeline
song_cluster_pipeline = Pipeline([
    ('scaler', StandardScaler()), # Standardises the features with mean 0 and std of 1
    ('kmeans', KMeans(n_clusters=20, verbose=False)) # Applies KMeans function, spliting the songs database into 20 clusters which have similar characteristics
])

X = data[number_cols]
song_cluster_pipeline.fit(X)
data['cluster_label'] = song_cluster_pipeline.predict(X)

# Spotify API setup - Might have to remove credentials after marking as it's exposed
sp = spotipy.Spotify(client_credentials_manager=SpotifyClientCredentials(
    client_id="1041b69041fc41ea96db8126959d9d7d",
    client_secret="b4df3d1e92fe433391921d6541689acb"
))

# Search the spotify database for the songs input by the user and return the audio features: the values that the songs have in the database
def find_song(name, artist): 
    song_data = defaultdict()
    results = sp.search(q=f'track: {name} artist: {artist}', limit=1)
    time.sleep(1)  # Spotify API gets overloaded with too many requests so need to give it time to load before accessing again

    if not results['tracks']['items']:
        return None

    track = results['tracks']['items'][0] # Extracts first track from the search results since there could be multiple resutls with the same search entries
    track_id = track['id']

    try:
        audio_features = sp.audio_features(track_id) # Fetches the audio features (i.e. valence) and stores them
        time.sleep(1)  # Delay API again

        if not audio_features:
            return None
        audio_features = audio_features[0]
    except Exception as e:
        print(f"Error retrieving audio features: {e}") # Error checking for spotify API
        return None

    song_data.update({
        'name': name,
        'artist': artist,
        'explicit': int(track['explicit']),
        'duration_ms': track['duration_ms'],
        'popularity': track['popularity']
    })
    song_data.update(audio_features) 

    return pd.DataFrame([song_data])

def get_song_data(song, spotify_data): # First checks to find the inputted song in the database before accessing the spotify database since there are already ~100,000 songs
    try:
        song_data = spotify_data[
            (spotify_data['name'] == song['name']) & 
            (spotify_data['year'] == song['year'])
        ].iloc[0]
        return song_data
    except IndexError:
        return find_song(song['name'], song['artist']) # If it can't find it, check the spotify database

def recommend_songs(song_list, spotify_data, scaler, n_songs=10): # The current recommendation system outputs 10 songs, can be increased if wanted
    song_vectors = [] 
    for song in song_list:
        song_data = get_song_data(song, spotify_data) # For each song input, retrieve the data necessary
        if song_data is None:
            continue
        song_vector = song_data[number_cols].values # Stores the numerical data in song_vectors
        song_vectors.append(song_vector)

    if not song_vectors:
        return []

    song_center = np.mean(song_vectors, axis=0).reshape(1, -1) # Calculates the mean of all the input songs numerical values to find the "centre" to compare the values against
    scaled_data = scaler.transform(spotify_data[number_cols])
    scaled_song_center = scaler.transform(song_center)
    distances = cdist(scaled_song_center, scaled_data, metric='cosine') # Calculate the distance between the user's "centre" and all other songs in the database
    indices = np.argsort(distances[0])[:n_songs]
    rec_songs = spotify_data.iloc[indices] # Selects the recommended songs that have the closest distance to the "centre"

    if 'artists' in rec_songs.columns:
        rec_songs['artists'] = rec_songs['artists'].apply(lambda x: x[0] if isinstance(x, list) else x) # If there are multiple artists, only take the first one as to not complicate the API requests

    metadata_cols = ['name', 'artists', 'year'] # Returns the relevant columns as a list of dictionaries
    return rec_songs[metadata_cols].to_dict(orient='records')

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        song_list = []
        for i in range(1, 6):
            name = request.form.get(f'name_{i}')
            artist = request.form.get(f'artist_{i}')
            year = request.form.get(f'year_{i}')
            if name and artist and year:
                song_list.append({'name': name, 'artist': artist, 'year': int(year)})

        if not song_list:
            return render_template('index.html', error="Please provide valid inputs.")

        recommendations = recommend_songs(song_list, data, song_cluster_pipeline.steps[0][1], n_songs=10)
        return render_template('recommendations.html', recommendations=recommendations) # Only renders recommendations.html if the correct data is passed through

    return render_template('index.html')


if __name__ == '__main__':
    app.run(debug=True)
